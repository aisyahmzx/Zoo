public class User {
    User[] users;
    String username;
    String password;
    int userCount=0;

    User(String username ,  String password){
        this.username = username;
        this.password = password;
    }



}
