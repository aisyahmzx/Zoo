public class Croc extends Animals {//croc inherit attributes and methods of animal
    public Croc(String animalName, String type, int age, double weight, String diet) {
        super(animalName, type, age, weight,diet);
    }
}
